package kata;

import org.hamcrest.CoreMatchers;
import org.junit.Assert;
import org.junit.Test;

import utils.CaesarCipher;
import utils.WordList;

import java.util.List;

public class WordListTests {

	List<String> strings; //Holds file input
	List<String> encryptedStrings; //holds encrypted version of file input
	List<String> decryptedStrings; //holds decrypted version of encryptedStrings
	int shiftInt = 29;
	
	public WordListTests() throws Exception{
		//prevent any error with the shift value being over the
		//length of the alphabet
		if(shiftInt > 26) {
			shiftInt = shiftInt%26;
		}
		//populate strings List with values from txt file
		strings = WordList.load();
		//populate encryptedStrings List with strings values put through a CaesarCipher with shift value of shiftInt
		encryptedStrings = CaesarCipher.EncryptString(strings, shiftInt);
		//populate decryptedStrings List with a CaesarCipher shift of shiftInt
		decryptedStrings = CaesarCipher.DecryptString(encryptedStrings, shiftInt);
	}
	
	//check size of strings List is equal to pre-known int
    @Test
    public void word_list_can_be_loaded() throws Exception {
    	//check that the input from file is the same size as pre-determined integer
        Assert.assertThat(strings.size(), CoreMatchers.is(CoreMatchers.equalTo(338882)));
    }
    
    //Check that the strings List does not equal the encryptedStrings list
    @Test
    public void Encryption_Sucessful() {
    	//for each String within the strings List
    	for(int i = 0; i<strings.size(); i++) {
    		//if strings at position i is not equal to encryptedStrings at position i
    		if(!strings.get(i).equals(encryptedStrings.get(i))) {
    			//assert true
    			Assert.assertTrue(true);
    		}
    		else {
    			//if the strings and encryptedStrings values are equal,
    			//assert false
    			Assert.assertTrue(false);
    		}
    	}
    }
    
    //Check that the strings List equals the decryptedStrings List
    @Test
    public void Decryption_Sucessful(){
    	//for each String within the strings List
    	for(int i = 0; i<strings.size(); i++) {
    		//if strings at position i is equal to decryptedStrings at position i 
    		if(strings.get(i).equals(decryptedStrings.get(i))) {
    			//assert true
    			Assert.assertTrue(true);
    		}
    		else {
    			//print out the line which has caused an error
    			System.out.println(strings.get(i) + " " + encryptedStrings.get(i) + " " + decryptedStrings.get(i));
        		//assert false
    			Assert.assertTrue(false);
    		}
    	}
    	
    }
}

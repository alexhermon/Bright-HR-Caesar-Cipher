package utils;

import java.util.ArrayList;
import java.util.List;

public class CaesarCipher {

	//Encrypt a given String List by a set int value
	public static List<String> EncryptString(List<String> strings, int shiftInt) throws Exception{
		
		List<String> encryptedString = new ArrayList<String>();
		String temp = "";
		
		//move through each string within strings List
		for(String s : strings) {
			//move through each char within the string s creating a new string (temp)
			for(int i = 0; i< s.length(); i++) {
				
				if(Character.isLetter(s.charAt(i))) {
					if(s.charAt(i) < 'A' || s.charAt(i) > 'z') 
					{ 
						temp += (char)(s.charAt(i) + shiftInt); 
					}
					//if character is going to move out of the alphabetical range, follow it round to
					//the beginning of the alphabet
					else if((s.charAt(i) + shiftInt > 'Z' && s.charAt(i) < 'a') || s.charAt(i) + shiftInt > 'z') 
					{ 
						temp += (char)(s.charAt(i) - (26-shiftInt)); 
					}
					//move the char ahead in the alphabet by the shiftInt
					else
					{ 
						temp += (char)(s.charAt(i) + shiftInt); 
					}
				}
				else { temp += (char) (s.charAt(i) + 3); }
			}
			//add the new string to the new encrypted List
			encryptedString.add(temp);
			//reset temp variable
			temp = "";
		}
		//return encryptedString List
		return encryptedString;
	}
	
	
	//Encrypt a given String List by a set int value
	public static List<String> DecryptString(List<String> encryptedString, int shiftInt) throws Exception{
		
		List<String> decryptedString = new ArrayList<String>();
		String temp = "";
		
		//move through each string within strings List
		for(String s : encryptedString) {
			//move through each char within the string s creating a new string (temp)
			for(int i = 0; i< s.length(); i++) {
				
				if(Character.isLetter(s.charAt(i))) {
					if(s.charAt(i) < 'A' || s.charAt(i) > 'z')
					{
						temp += (char)(s.charAt(i) - shiftInt);
					}
					//if character is going to move out of the alphabetical range, follow it round to
					//the end of the alphabet
					else if((s.charAt(i) - shiftInt < 'a' && s.charAt(i) > 'Z') || s.charAt(i) - shiftInt < 'A') 
					{ 
						temp += (char)(s.charAt(i) + (26-shiftInt)); 
					}
					//move the char ahead in the alphabet by the shiftInt
					else 
					{ 
						temp += (char)(s.charAt(i) - shiftInt); 
					}
				}
				else {
					temp += (char) (s.charAt(i) - 3);
				}
			}
			//add the new string to the new encrypted List
			decryptedString.add(temp);
			//reset temp variable
			temp = "";
		}
		//return encryptedString List
		return decryptedString;
	}
}

package utils;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class WordList {

    public static List<String> load() throws IOException {
    	//open wordlist file from default programme location 
        BufferedReader abc = new BufferedReader(new FileReader(System.getProperty("user.dir") + "\\wordlist.txt"));
        //String list to hold file intput
        List<String> lines = new ArrayList<>();

        //String holds current input line from file
        String line;
        while((line = abc.readLine()) != null) {
            lines.add(line);
        }
        //close file
        abc.close();
        //return String List to source
        return lines;
    }
}
